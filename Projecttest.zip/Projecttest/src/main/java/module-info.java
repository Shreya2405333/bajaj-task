module com.projecttest {
		requires java.base; // Default module (optional but implied)
		requires org.json;  // Add this to read the org.json module

		}
